# 导入所需的库
import time  # 用于计时，time.time()返回当前时间戳

# 导入数据处理和可视化相关的库
import pandas as pd  # pandas库用于数据处理和CSV文件读取
import matplotlib.pyplot as plt  # matplotlib库用于数据可视化
import numpy as np  # numpy库用于数值计算
from numpy import nonzero, array  # 从numpy导入specific函数：nonzero()返回非零元素的索引，array()创建数组
from sklearn.cluster import KMeans  # 从sklearn导入KMeans算法实现
# 导入评估指标相关的函数
from sklearn.metrics import f1_score, accuracy_score, normalized_mutual_info_score, rand_score, adjusted_rand_score
from sklearn.preprocessing import LabelEncoder  # 用于将文本标签转换为数字标签
from sklearn.decomposition import PCA  # 用于降维处理

# 读取各种数据集，pd.read_csv()函数用于读取CSV文件
# header=0 表示将第一行作为列名
iris = pd.read_csv("dataset/Iris.csv", header=0)  # 鸢尾花数据集 Iris  class=3
wine = pd.read_csv("dataset/wine.csv")  # 葡萄酒数据集 Wine  class=3
seeds = pd.read_csv("dataset/seeds.csv")  # 小麦种子数据集 seeds  class=3
wdbc = pd.read_csv("dataset/wdbc.csv")  # 威斯康星州乳腺癌数据集 class=2
glass = pd.read_csv("dataset/glass.csv")  # 玻璃辨识数据集 Glass Identification  class=6
aggregation = pd.read_csv("dataset/aggregation.csv")  # class=7
flame = pd.read_csv("dataset/flame.csv")  # class=2
jain = pd.read_csv("dataset/jain.csv")  # class=2
spiral = pd.read_csv("dataset/spiral.csv")  # class=3
df = iris  # 设置当前使用的数据集为iris

# 数据预处理
columns = list(df.columns)  # 获取数据集的所有列名，转换为list类型
features = columns[:len(columns) - 1]  # 特征列名列表，切片操作[:len(columns) - 1]表示取除最后一列外的所有列
dataset = df[features]  # 使用特征列名从数据框中选择特征数据
attributes = len(df.columns) - 1  # 计算特征维度（属性数量）
original_labels = list(df[columns[-1]])  # 获取原始标签，columns[-1]表示最后一列

def initialize_centroids(data, k):
    """
    初始化聚类中心
    参数：
    data: numpy数组，输入数据
    k: int，聚类簇数
    返回：
    centers: numpy数组，初始聚类中心
    """
    # np.random.choice()从data.shape[0]范围内随机选择k个不重复的索引
    # replace=False表示不允许重复选择
    centers = data[np.random.choice(data.shape[0], k, replace=False)]
    return centers

def get_clusters(data, centroids):
    """
    将数据点分配到最近的聚类中心
    参数：
    data: numpy数组，输入数据
    centroids: numpy数组，当前聚类中心
    返回：
    cluster_labels: numpy数组，每个数据点的簇标签
    """
    # np.newaxis用于增加一个维度，便于广播计算
    # np.linalg.norm计算欧氏距离
    # axis=2表示在第三个维度上计算范数
    distances = np.linalg.norm(data[:, np.newaxis] - centroids, axis=2)
    # np.argmin返回最小值的索引，即找到最近的聚类中心
    cluster_labels = np.argmin(distances, axis=1)
    return cluster_labels

def update_centroids(data, cluster_labels, k):
    """
    更新聚类中心
    参数：
    data: numpy数组，输入数据
    cluster_labels: numpy数组，当前的簇标签
    k: int，聚类簇数
    返回：
    new_centroids: numpy数组，更新后的聚类中心
    """
    # 列表推导式：对每个簇计算均值
    # cluster_labels == i 创建布尔索引
    # .mean(axis=0)在第一个维度上计算均值
    new_centroids = np.array([data[cluster_labels == i].mean(axis=0) for i in range(k)])
    return new_centroids

def k_means(data, k, T, epsilon):
    """
    K-means聚类算法主函数
    参数：
    data: numpy数组，输入数据
    k: int，聚类簇数
    T: int，最大迭代次数
    epsilon: float，收敛阈值
    返回：
    cluster_labels: numpy数组，最终的簇标签
    centroids: numpy数组，最终的聚类中心
    """
    start = time.time()  # 记录开始时间
    centroids = initialize_centroids(data, k)  # 初始化聚类中心
    t = 0  # 迭代计数器
    
    while t <= T:  # 主循环，直到达到最大迭代次数
        cluster_labels = get_clusters(data, centroids)  # 分配簇标签
        new_centroids = update_centroids(data, cluster_labels, k)  # 更新聚类中心
        
        # 检查收敛条件：如果新旧聚类中心的差异小于阈值，则停止迭代
        if np.linalg.norm(new_centroids - centroids) < epsilon:
            break
            
        centroids = new_centroids  # 更新聚类中心
        print("第", t, "次迭代")
        t += 1
    
    print("用时：{0}".format(time.time() - start))  # 输出运行时间
    return cluster_labels, centroids

def clustering_indicators(labels_true, labels_pred):
    """
    计算聚类评估指标
    参数：
    labels_true: 真实标签
    labels_pred: 预测标签
    返回：
    多个评估指标值
    """
    # 如果真实标签不是整数类型，使用LabelEncoder转换为数字标签
    if type(labels_true[0]) != int:
        labels_true = LabelEncoder().fit_transform(df[columns[len(columns) - 1]])
    
    # 计算各种评估指标
    f_measure = f1_score(labels_true, labels_pred, average='macro')  # F1分数
    accuracy = accuracy_score(labels_true, labels_pred)  # 准确率
    normalized_mutual_information = normalized_mutual_info_score(labels_true, labels_pred)  # 标准化互信息
    rand_index = rand_score(labels_true, labels_pred)  # 兰德指数
    ARI = adjusted_rand_score(labels_true, labels_pred)  # 调整兰德指数
    return f_measure, accuracy, normalized_mutual_information, rand_index, ARI

def draw_cluster(dataset, centers, labels):
    """
    绘制聚类结果散点图
    参数：
    dataset: 数据集
    centers: 聚类中心
    labels: 簇标签
    """
    center_array = array(centers)
    
    # 如果特征维度>2，使用PCA降至2维
    if attributes > 2:
        dataset = PCA(n_components=2).fit_transform(dataset)
        center_array = PCA(n_components=2).fit_transform(center_array)
    else:
        dataset = array(dataset)
    
    # 绘制散点图
    label = array(labels)
    plt.scatter(dataset[:, 0], dataset[:, 1], marker='o', c='black', s=7)  # 绘制原始数据点
    
    # 定义不同簇的颜色
    colors = np.array([
        "#FF0000", "#0000FF", "#00FF00", "#FFFF00", "#00FFFF", "#FF00FF",
        "#800000", "#008000", "#000080", "#808000", "#800080", "#008080",
        "#444444", "#FFD700", "#008080"
    ])
    
    # 为每个簇绘制不同颜色的散点图
    for i in range(k):
        plt.scatter(
            dataset[nonzero(label == i), 0],  # x坐标
            dataset[nonzero(label == i), 1],  # y坐标
            c=colors[i],  # 颜色
            s=7,  # 点的大小
            marker='o'  # 点的形状
        )
    
    plt.show()  # 显示图形

# 主程序入口
if __name__ == "__main__":
    k = 3  # 设置聚类簇数
    T = 100  # 设置最大迭代次数
    n = len(dataset)  # 计算样本数量
    epsilon = 1e-5  # 设置收敛阈值
    
    # 执行K-means聚类
    labels, centers = k_means(np.array(dataset), k, T, epsilon)
    
    # 计算并输出聚类评估指标
    F_measure, ACC, NMI, RI, ARI = clustering_indicators(original_labels, labels)
    print("F_measure:", F_measure, "ACC:", ACC, "NMI", NMI, "RI", RI, "ARI", ARI)
    
    # 绘制聚类结果
    draw_cluster(dataset, centers, labels=labels)

# sklearn的KMeans实现（已注释掉）
# model = KMeans(n_clusters=k)
# model.fit(dataset)
# label = model.predict(dataset)
# print(label)